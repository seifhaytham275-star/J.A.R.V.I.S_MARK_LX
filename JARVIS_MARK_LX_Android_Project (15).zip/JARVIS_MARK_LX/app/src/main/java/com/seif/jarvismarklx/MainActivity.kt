package com.seif.jarvismarklx

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val voiceRequestCode = 7421
    private val modelId = "gemini-3.8-flash"

    private fun securePrefs() = EncryptedSharedPreferences.create(
        this,
        "jarvis_secure_settings",
        MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(3, 10, 20)
        window.navigationBarColor = android.graphics.Color.rgb(3, 10, 20)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (url.startsWith("file:///android_asset/")) return false
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { }
                    return true
                }
                return true
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                return shouldOverrideUrlLoading(view, request.url.toString())
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(NativeBridge(), "AndroidBridge")
        setContentView(webView)
        if (securePrefs().getString("gemini_api_key", null).isNullOrBlank()) {
            showApiKeyDialog(firstRun = true) { webView.loadUrl("file:///android_asset/index.html") }
        } else {
            webView.loadUrl("file:///android_asset/index.html")
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("ar", "EG")
    }

    private fun showApiKeyDialog(firstRun: Boolean, afterSave: (() -> Unit)? = null) {
        val input = EditText(this).apply {
            hint = "AIza…"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            setText(securePrefs().getString("gemini_api_key", "") ?: "")
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 12, 48, 0)
            addView(input, LinearLayout.LayoutParams(-1, -2))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(if (firstRun) "Set up Gemini" else "Change Gemini API Key")
            .setMessage("Enter your Gemini API key. It will be stored encrypted on this device and won't be requested on every launch.")
            .setView(box)
            .setCancelable(!firstRun)
            .setPositiveButton("Save", null)
            .apply { if (!firstRun) setNegativeButton("Cancel", null) }
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val key = input.text.toString().trim()
                if (key.length < 20) {
                    input.error = "Enter a valid-looking API key"
                    return@setOnClickListener
                }
                securePrefs().edit().putString("gemini_api_key", key).apply()
                dialog.dismiss()
                Toast.makeText(this, "Gemini key saved on this device", Toast.LENGTH_SHORT).show()
                afterSave?.invoke()
            }
        }
        dialog.show()
    }

    inner class NativeBridge {
        @JavascriptInterface fun askGemini(message: String, historyJson: String, requestId: String) {
            worker.execute {
                val result = try { JSONObject().put("ok", true).put("reply", callGemini(message, historyJson)) }
                catch (e: Exception) { JSONObject().put("ok", false).put("error", (e.message ?: "Request failed").take(240)) }
                runOnUiThread {
                    val safeId = JSONObject.quote(requestId)
                    val safePayload = JSONObject.quote(result.toString())
                    webView.evaluateJavascript("window.onNativeGeminiReply($safeId,$safePayload)", null)
                }
            }
        }

        @JavascriptInterface fun changeApiKey() = runOnUiThread { showApiKeyDialog(firstRun = false) }
        @JavascriptInterface fun speak(text: String) = runOnUiThread {
            if (ttsReady) {
                val language = if (text.any { it in '\u0600'..'\u06FF' }) Locale("ar", "EG") else Locale.US
                tts?.language = language
                tts?.speak(text.take(4000), TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
            }
        }
        @JavascriptInterface fun startVoiceRecognition() = runOnUiThread {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to JARVIS")
                }
                startActivityForResult(intent, voiceRequestCode)
            } catch (_: Exception) {
                Toast.makeText(this@MainActivity, "Voice input is not available on this device", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun callGemini(message: String, historyJson: String): String {
        val key = securePrefs().getString("gemini_api_key", null)?.trim().orEmpty()
        if (key.isBlank()) throw IllegalStateException("Gemini API key is missing. Open Settings to add it.")
        val contents = JSONArray()
        try {
            val history = JSONArray(historyJson)
            for (i in 0 until minOf(history.length(), 20)) {
                val item = history.getJSONObject(i)
                val role = if (item.optString("role") == "user") "user" else "model"
                val text = item.optString("content").take(10000)
                if (text.isNotBlank()) contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text))))
            }
        } catch (_: Exception) { }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", message.take(12000)))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "You are J.A.R.V.I.S MARK LX, a helpful personal AI assistant. Speak natural Egyptian Arabic when the user writes Arabic and clear casual English when they write English. Be honest about device capabilities. Ask before consequential actions."))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 2048))
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", key)
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val response = JSONObject(responseText)
            if (code !in 200..299) {
                val apiMessage = response.optJSONObject("error")?.optString("message").orEmpty()
                throw IllegalStateException(if (apiMessage.isNotBlank()) "Gemini API ($code): $apiMessage" else "Gemini API returned HTTP $code")
            }
            val candidates = response.optJSONArray("candidates") ?: throw IllegalStateException("Gemini returned no candidates")
            val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw IllegalStateException("Gemini response was empty")
            val out = StringBuilder()
            for (i in 0 until parts.length()) out.append(parts.optJSONObject(i)?.optString("text").orEmpty())
            if (out.isBlank()) throw IllegalStateException("Gemini returned an empty answer")
            return out.toString().trim()
        } finally { connection.disconnect() }
    }

    @Deprecated("Deprecated in Android API, retained for broad device support")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequestCode && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) webView.evaluateJavascript("window.onNativeVoiceResult(${JSONObject.quote(spoken)})", null)
        }
    }

    @Deprecated("Deprecated in Android API, retained for broad device support")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        tts?.stop()
        tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }
}
